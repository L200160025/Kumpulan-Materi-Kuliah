# TIF50533-SIstem-Manajemen-Basisdata-20181
Catatan kuliah semester Ganjil 2018

## [Catatan Kuliah SEMESTER GANJIL 2017](https://github.com/handaga/Database-Management-System-2017)
