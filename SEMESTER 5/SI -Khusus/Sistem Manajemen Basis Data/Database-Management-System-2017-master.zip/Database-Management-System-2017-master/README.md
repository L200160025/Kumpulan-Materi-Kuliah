# [Sistem Manajemen basisdata SEMESTER GANJIL 2018](https://github.com/bana-handaga/TIF50533-SIstem-Manajemen-Basisdata-20181) 

# Database-Management-System-2017

-------------------------------------------
# Kisi-kisi UAS Ganjil 2017/2018
-------------------------------------------
open cheatsheet (1 hal - A4) 

## 1. MySQL Trigger 
## 2. MySQL Aggregate Function (built in)
## 3. MySQL Function (Store Function)
## 4. MySQL Fulltext Search
## 5. MySQL Views



-------------------------------------------




Catatan Kuliah DBMS semester Ganjil 2017


# Remidi UTS 2017 (27 November 2017)

Download [soal UTS](https://github.com/handaga/Database-Management-System-2017/blob/master/bana-uts-if-SistemManagegementBasisdata.docx) dan buatlah solusi lengkap untuk semua soal, selanjutnya upload ke github (NIM) masing-masing.
Dokumen jawaban bebas, boleh tulis tangan, office atau yang lainnnya, yang penting di upload di github.
---------------------------




# Tugas-01:


Download CONTOH DATABASE:  ("classicmodels")[http://www.mysqltutorial.org/mysql-sample-database.aspx
]

Import ke dalam sistem basisdata, dan digunakan sebagai contoh basis data, selama belajar matakuliah DBMS. 

Identifikasi STRUKTURE dan RELASI (one-to-one, one-to-many dll)  buatlah dalam bentuk  ER Diagram, upload di GITHUB

Berikan penjelasan terhadap setiap gambar yang ditampilkan


# Tugas-02:
Buatlah ROLE dan HAK AKSES (GRANT) terkait er-diagram pada tugas-01:

## Hint:
Minimal kelompok user:
		(1) Pemilik Retail
		(2) Supervisor (manager)
		(3) Operator (kasir)

Berikan penjelasan sedetail mungkin terkait hak akses dan role yang diberikan pasa user.




